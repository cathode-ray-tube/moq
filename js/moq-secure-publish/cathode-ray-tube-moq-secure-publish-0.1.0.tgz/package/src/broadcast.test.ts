import { expect, test } from "bun:test";
import * as Catalog from "@moq/hang/catalog";
import * as Json from "@moq/json";
import { Origin, Path, Track } from "@moq/net";
import { Effect, Signal } from "@moq/signals";
import { Broadcast } from "./broadcast.ts";

// Effects and signal writes coalesce onto microtasks, so a chain of registration -> config -> catalog
// needs a few flushes to settle.
const flush = () => new Promise<void>((resolve) => queueMicrotask(resolve));
async function settle(times = 5): Promise<void> {
	for (let i = 0; i < times; i++) await flush();
}

// Read the current catalog by seeding a fresh subscriber (CatalogProducer seeds each one).
async function readCatalog(broadcast: Broadcast): Promise<Catalog.Root | undefined> {
	const effect = new Effect();
	const track = new Track.Producer("catalog.json");
	broadcast.catalog.serve(track, effect);
	const catalog = await new Json.Snapshot.Consumer<Catalog.Root>({ track: track.subscribe() }).next();
	effect.close();
	return catalog;
}

const videoConfig: Catalog.VideoConfig = { codec: "avc1.640028", container: { kind: "legacy" } };
const audioConfig: Catalog.AudioConfig = {
	codec: "opus",
	sampleRate: Catalog.u53(48000),
	numberOfChannels: Catalog.u53(2),
	container: { kind: "legacy" },
};

test("folds video and audio renditions into the catalog by full track name", async () => {
	const broadcast = new Broadcast({ enabled: true, display: { width: 1920, height: 1080 }, flip: true });

	broadcast.video("video/hd").config.set(videoConfig);
	broadcast.audio("audio/data").config.set(audioConfig);
	await settle();

	const catalog = await readCatalog(broadcast);
	expect(catalog?.video?.renditions["video/hd"]?.codec).toBe("avc1.640028");
	expect(Number(catalog?.video?.display?.width)).toBe(1920);
	expect(Number(catalog?.video?.display?.height)).toBe(1080);
	expect(catalog?.video?.flip).toBe(true);
	expect(catalog?.audio?.renditions["audio/data"]?.codec).toBe("opus");

	broadcast.close();
});

test("a rendition with an undefined config is omitted from the catalog", async () => {
	const broadcast = new Broadcast({ enabled: true });

	const hd = broadcast.video("video/hd");
	const sd = broadcast.video("video/sd");
	hd.config.set(videoConfig);
	sd.config.set(videoConfig);
	await settle();

	let catalog = await readCatalog(broadcast);
	expect(Object.keys(catalog?.video?.renditions ?? {})).toEqual(["video/hd", "video/sd"]);

	// Clearing one config drops just that entry.
	sd.config.set(undefined);
	await settle();
	catalog = await readCatalog(broadcast);
	expect(Object.keys(catalog?.video?.renditions ?? {})).toEqual(["video/hd"]);

	// Clearing the last leaves no defined configs, so the whole section is deleted.
	hd.config.set(undefined);
	await settle();
	catalog = await readCatalog(broadcast);
	expect(catalog?.video).toBeUndefined();

	broadcast.close();
});

test("a duplicate track name throws across both kinds", () => {
	const broadcast = new Broadcast({ enabled: true });

	broadcast.video("video/hd");
	expect(() => broadcast.video("video/hd")).toThrow();
	// The single registry enforces uniqueness across video and audio.
	expect(() => broadcast.audio("video/hd")).toThrow();

	broadcast.close();
});

test("rendition.close() unregisters the name and drops it from the catalog", async () => {
	const broadcast = new Broadcast({ enabled: true });

	const hd = broadcast.video("video/hd");
	hd.config.set(videoConfig);
	await settle();
	expect((await readCatalog(broadcast))?.video?.renditions["video/hd"]).toBeDefined();

	hd.close();
	await settle();
	expect((await readCatalog(broadcast))?.video).toBeUndefined();

	// The name is free to register again.
	expect(() => broadcast.video("video/hd")).not.toThrow();

	broadcast.close();
});

test("subscriber demand hands the producer to the rendition and clears it when the track closes", async () => {
	const broadcast = new Broadcast({ enabled: true, origin: new Origin.Producer(), name: Path.from("test.hang") });
	await settle();

	const net = broadcast.net.peek();
	if (!net) throw new Error("expected a network producer once connected");

	const rendition = broadcast.video("video");
	await settle();
	const subscriber = net.track("video").subscribe();
	await settle();

	// The request loop accepted the subscription and handed the producer to the rendition.
	const track = rendition.track.peek();
	expect(track).toBeDefined();

	// Closing the producer (encoder error / teardown) clears the signal, with no lingering per-subscription
	// effect watching it.
	track?.close();
	await settle();
	expect(rendition.track.peek()).toBeUndefined();

	subscriber.close();
	broadcast.close();
});

test("serves the catalog through a shared static track", async () => {
	const broadcast = new Broadcast({ enabled: true, origin: new Origin.Producer(), name: Path.from("test.hang") });
	broadcast.video("video").config.set(videoConfig);
	await settle();

	const net = broadcast.net.peek();
	if (!net) throw new Error("expected a network producer once connected");

	const subscriber = net.track(Broadcast.CATALOG_TRACK).subscribe();
	const catalog = await new Json.Snapshot.Consumer<Catalog.Root>({ track: subscriber }).next();
	expect(catalog?.video?.renditions.video?.codec).toBe("avc1.640028");

	// Dropping the subscriber closes the served track; the broadcast keeps running for the next viewer.
	subscriber.close();
	await settle();
	expect(broadcast.net.peek()).toBe(net);

	broadcast.close();
});

// Regression: the catalog was served from the moment the origin existed, so the snapshots published
// while renditions resolved stayed on the track and a subscriber could start from a partial one.
test("serves no catalog until announced, so the first snapshot is the one at announce time", async () => {
	const announce = new Signal(false);
	const broadcast = new Broadcast({
		enabled: true,
		origin: new Origin.Producer(),
		name: Path.from("test.hang"),
		announce,
	});
	await settle();

	// Renditions resolve in separate ticks while unannounced.
	broadcast.video("video").config.set(videoConfig);
	await settle();
	broadcast.audio("audio").config.set(audioConfig);
	await settle();

	announce.set(true);
	await settle();

	const net = broadcast.net.peek();
	if (!net) throw new Error("expected a network producer once connected");

	const group = await net.track(Broadcast.CATALOG_TRACK).subscribe().ordered().nextGroup();
	expect(group?.sequence).toBe(0);
	const catalog = (await group?.readJson()) as Catalog.Root;
	expect(Object.keys(catalog.video?.renditions ?? {})).toEqual(["video"]);
	expect(Object.keys(catalog.audio?.renditions ?? {})).toEqual(["audio"]);

	broadcast.close();
});

test("keeps the current catalog snapshot for a reconnecting viewer", async () => {
	const real = performance.now.bind(performance);
	let now = real();
	performance.now = () => now;

	try {
		const broadcast = new Broadcast({
			enabled: true,
			origin: new Origin.Producer(),
			name: Path.from("test.hang"),
		});
		broadcast.video("video").config.set(videoConfig);
		await settle();

		const net = broadcast.net.peek();
		if (!net) throw new Error("expected a network producer once connected");

		const first = net.track(Broadcast.CATALOG_TRACK).subscribe();
		expect((await new Json.Snapshot.Consumer<Catalog.Root>({ track: first }).next())?.video).toBeDefined();
		first.close();

		// A reconnect past the idle cache window must still receive the live track's newest
		// snapshot instead of waiting forever for an edit that may never come.
		now += 60_000;
		const second = net.track(Broadcast.CATALOG_TRACK).subscribe();
		expect((await new Json.Snapshot.Consumer<Catalog.Root>({ track: second }).next())?.video).toBeDefined();
		second.close();

		broadcast.close();
	} finally {
		performance.now = real;
	}
});
