import * as Catalog from "@moq/hang/catalog";
import * as Container from "@moq/hang/container";
import * as Util from "@moq/hang/util";
import type * as Moq from "@moq/net";
import { Time } from "@moq/net";
import {
	type Computed,
	Effect,
	type Getter,
	getter,
	type Inputs,
	type Readonlys,
	readonlys,
	Signal,
} from "@moq/signals";
import type { Broadcast } from "../broadcast";
import { type Baseline, Estimator } from "../jitter";
import type { AudioFrame, Capture, Format } from "./capture";
import { Gain } from "./gain";
import { Resampler } from "./resampler";
import type { CodecMime, Kind } from "./types";
import { sourceKind } from "./types";

const OPUS_BITRATE_PER_CHANNEL = 32_000;
const OPUS_FRAME_DURATION = Time.Milli(20);
// The only frame durations libopus (and so WebCodecs) will encode, in ms.
const OPUS_FRAME_DURATIONS = [2.5, 5, 10, 20, 40, 60];
const AAC_BITRATE_PER_CHANNEL = 64_000;
const AAC_FRAME_SAMPLES = 1024; // AAC-LC encodes a fixed 1024 samples per frame.
// Long enough that a volume change doesn't click, short enough that a mute is silent almost at once.
const FADE = Time.Milli(50);

// The WebCodecs/MP4 codec string for AAC-LC. "aac" is our user-facing shorthand.
const AAC_CODEC = "mp4a.40.2";

import { Framer } from "./framer";

// Selects the audio codec and its encoder settings. Either the bare codec name (all defaults) or an
// object with the mime plus tuning knobs.
export type Codec = Opus | Aac;

export type Opus = "opus" | OpusConfig;
export type Aac = "aac" | AacConfig;

// AAC encoder settings. AAC-LC has a fixed 1024-sample frame and no real-time tuning knobs, so
// bitrate is the only thing to configure.
export type AacConfig = {
	mime: "aac";

	bitrate?: number; // bits/sec, defaults to channelCount * 64kbps
};

// Opus encoder settings. bitrate and frameDuration also shape the catalog (decoders need them); the
// rest are encode-only knobs that map directly to the matching OpusEncoderConfig fields:
// https://developer.mozilla.org/en-US/docs/Web/API/AudioEncoder/configure#opus
export type OpusConfig = {
	mime: "opus";

	bitrate?: number; // bits/sec, defaults to channelCount * 32kbps
	// The type carries the unit (ms): build with Time.Milli(20). Opus takes exactly 2.5, 5, 10, 20,
	// 40, or 60 ms, and defaults to 20.
	frameDuration?: Time.Milli;
	complexity?: number; // 0-10, higher is better quality but more CPU
	packetlossperc?: number; // 0-100, expected loss the encoder optimizes for
	useinbandfec?: boolean; // in-band forward error correction
};

/** Cumulative encoder output totals, measured from the chunks the encoder produces. */
export interface Stats {
	/** Total frames encoded while serving. Monotonic; diff over an interval for a frame rate. */
	frames: number;

	/** Total bytes encoded while serving. Monotonic; diff over an interval for an upload bitrate. */
	bytes: number;
}

// Signals the encoder reads.
export type EncoderInput = {
	// Whether to publish (and encode) this rendition. Defaults to true. When false the rendition drops out of the
	// catalog and stops encoding, ending the epoch, but stays registered so a subscriber still gets an idle track.
	enabled: Getter<boolean>;

	// The broadcast to register the rendition on. Undefined resolves the config but has nowhere to publish.
	broadcast: Getter<Broadcast | undefined>;

	// The capture supplying PCM. Shared: one capture feeds any number of renditions, so build it
	// yourself and pass the same instance to each.
	capture: Getter<Capture | undefined>;

	// The connection's bandwidth allocator. Audio reserves its configured bitrate so
	// video's share is honest, and ignores the grant (Opus is a fixed rate today).
	bandwidth: Getter<Moq.Bandwidth.Handle | undefined>;
};

/** Constructor options: the wired inputs plus the live-editable tuning knobs. */
export type EncoderProps = Inputs<EncoderInput> & {
	// User tuning knobs. Seed a value or wire a Signal; also live-editable via the matching field.
	volume?: number | Signal<number>;

	// How long a volume change ramps for, so a mute is silent once it passes. Defaults to 50 ms; 0
	// steps at once.
	fade?: Time.Milli | Signal<Time.Milli>;

	// Codec selection plus encoder settings. Defaults to "opus".
	codec?: Codec | Signal<Codec>;
};

type EncoderOutput = {
	// The catalog config published for this rendition, or undefined while there's no capture.
	catalog: Signal<Catalog.AudioConfig | undefined>;
	// The head of the capture graph, so callers can tap the raw capture. Volume is applied to the
	// PCM rather than in the graph, so this is pre-gain. Undefined for a source that isn't a track.
	root: Signal<AudioNode | undefined>;
	// True when a subscriber is attached and we're encoding.
	active: Signal<boolean>;
	// Cumulative output totals (frames, bytes) measured while serving.
	stats: Signal<Stats>;
};

// One configured encode chain. Rebuilt whenever the resolved config changes; the capture read loop
// pushes into whichever one is current, so a codec change never interrupts the source.
type Pipeline = {
	channelCount: number;
	push(frame: AudioFrame): void;
};

/**
 * A single audio rendition encoder.
 *
 * Registers itself on the {@link Broadcast} under {@link name} (via `broadcast.audio(name)`), pumps PCM
 * off the source via a {@link Capture}, and encodes it only while a subscriber is attached (the demand
 * gate). Rename by constructing a new encoder; the name is not a signal.
 */
export class Encoder {
	/** The full track name of this rendition, e.g. `"audio/data"`. */
	readonly name: string;

	readonly in: Readonlys<EncoderInput>;

	/** Linear gain applied before encoding, where 1 is unity. Each change ramps over {@link fade}. */
	volume: Signal<number>;
	/** How long a volume change ramps for, whatever its size. 0 steps at once; a negative or non-finite fade refuses the rendition. */
	fade: Signal<Time.Milli>;
	/** The live-editable codec selection plus its encoder settings. */
	codec: Signal<Codec>;

	/**
	 * The capture supplying this rendition, or undefined while none is wired.
	 *
	 * A snapshot, for reaching the shared capture format knobs (`audio.capture?.sampleRate`). Read
	 * {@link in}.capture through an effect instead when you need to react to it being swapped.
	 */
	get capture(): Capture | undefined {
		return this.in.capture.peek();
	}

	// The encode settings known before encoding starts. Opus adds its decoder description from the
	// first encoder output without feeding that catalog-only update back into the encoder.
	#config = new Signal<Resolved | undefined>(undefined);
	#decoderDescription = new Signal<{ config: Catalog.AudioConfig; description: Catalog.Hex } | undefined>(undefined);

	readonly #out: EncoderOutput = {
		catalog: new Signal<Catalog.AudioConfig | undefined>(undefined),
		root: new Signal<AudioNode | undefined>(undefined),
		active: new Signal<boolean>(false),
		stats: new Signal<Stats>({ frames: 0, bytes: 0 }),
	};
	readonly out = readonlys(this.#out);

	// The encode chain currently publishing, or undefined while nothing is. The read loop pushes
	// into this; frames that arrive while it's undefined are dropped, which the framer treats as a
	// discontinuity and re-anchors on.
	#pipeline: Pipeline | undefined;

	// The current subscription's track and the producer writing into it, or undefined without demand.
	#live: { track: Moq.Track.Producer; producer: Container.Legacy.Producer } | undefined;

	// Where the next frame submitted to the AudioEncoder starts, i.e. the exclusive end of the
	// newest one, where an epoch's discontinuity marker goes. Cleared once the marker is written.
	#next: Time.Micro | undefined;

	// The newest epoch's marker. The AudioEncoder outlives a demand gap too brief to skip a frame,
	// so chunks it still held when demand disappeared surface after the resume; they sit below the
	// marker and are dropped.
	#floor: Time.Micro | undefined;

	// The last valid fade, which the read loop ramps with. #runConfig refuses the rendition on an
	// invalid one, so a bad value never reaches the gain.
	#fade: Time.Milli = FADE;

	// The fatal error an AudioEncoder reported, if any. That instance can never encode again and
	// reconfiguring it would be a retry, so the rendition stays down for the life of this encoder.
	#fatal = new Signal<Error | undefined>(undefined);

	// How many resolution runs threw for their current inputs (e.g. invalid codec settings), so no
	// config is coming until one reruns.
	#failures = new Signal(0);

	/**
	 * @internal Whether the catalog config resolved, or can't until something outside the encoder
	 * changes: a failed encoder or capture, invalid codec settings, or a capture waiting on the page's
	 * first gesture. `<moq-publish>` holds its first announce until this is set.
	 */
	readonly settled: Computed<boolean>;

	#signals = new Effect();
	#estimator = new Estimator();

	constructor(name: string, props?: EncoderProps) {
		// `source` moved to Audio.Capture, which renditions share. TypeScript catches this, but a
		// plain JS caller would otherwise get an encoder with nothing attached: no catalog, no
		// audio, and nothing to explain why.
		if (props && "source" in props) {
			throw new Error("Audio.Encoder: `source` moved to Audio.Capture; construct one and pass `capture`");
		}

		this.name = name;
		this.in = {
			enabled: getter(props?.enabled ?? true),
			broadcast: getter(props?.broadcast),
			capture: getter(props?.capture),
			bandwidth: getter(props?.bandwidth),
		};
		this.volume = Signal.from(props?.volume ?? 1);
		this.fade = Signal.from(props?.fade ?? FADE);
		this.codec = Signal.from<Codec>(props?.codec ?? "opus");

		// Only the capture graph has a node to expose.
		this.#signals.run((effect) => {
			const capture = effect.get(this.in.capture);
			if (!capture) return;
			effect.proxy(this.#out.root, capture.out.root);
		});

		this.settled = this.#signals.computed((effect) => {
			if (effect.get(this.#out.catalog) !== undefined) return true;
			if (effect.get(this.#fatal) !== undefined || effect.get(this.#failures) > 0) return true;
			const capture = effect.get(this.in.capture);
			return capture !== undefined && !!effect.get(capture.blocked);
		});

		this.#signals.run(this.#runCapture.bind(this));

		// Every step that resolves the config counts a throw as a failure, so a bad input settles the
		// gate instead of holding the announce forever.
		for (const run of [this.#runConfig, this.#runCatalog]) {
			this.#signals.run((effect) => {
				try {
					run.call(this, effect);
				} catch (err) {
					this.#failures.update((n) => n + 1);
					effect.cleanup(() => this.#failures.update((n) => n - 1));
					throw err;
				}
			});
		}
		this.#signals.run(this.#runRegister.bind(this));
	}

	// Pump PCM off the capture into whatever is currently publishing, applying the volume knobs on
	// the way through. Tied to the capture's lifetime rather than the encoder's, so reconfiguring
	// never has to reacquire the stream, which for a decoded file would be fatal.
	#runCapture(effect: Effect): void {
		const capture = effect.get(this.in.capture);
		if (!capture) return;

		const fanout = effect.get(capture.out.frames);
		if (!fanout) return;

		// Our own stream off the shared capture, so another rendition reading slowly can't take
		// frames from this one.
		const reader = fanout.subscribe(effect).getReader();
		effect.cleanup(() => {
			reader.cancel().catch(() => {});
		});

		const gain = new Gain(this.volume.peek());

		effect.spawn(async () => {
			for (;;) {
				const next = await effect.race(reader.read());
				if (!next?.value) break;

				const format = capture.out.format.peek();
				if (!format) continue;

				// Every rendition shares the captured frame, so gain returns a copy rather than
				// scaling in place; muting one rendition must not silence the rest.
				gain.set(this.volume.peek(), this.#fade);
				const frame = gain.apply(next.value, format.sampleRate);

				// The config rebuilds when the channel count moves, so skip anything that arrives
				// mid-swap rather than framing it wrong.
				const pipeline = this.#pipeline;
				if (pipeline && pipeline.channelCount === frame.channels.length) pipeline.push(frame);
			}
		});
	}

	// Register the rendition on the broadcast, publish its config, and encode only while a subscriber
	// is attached (the demand gate). Re-registers cleanly when the broadcast swaps.
	#runRegister(effect: Effect): void {
		const broadcast = effect.get(this.in.broadcast);
		if (!broadcast) return;

		const rendition = broadcast.audio(this.name);
		effect.cleanup(() => rendition.close());

		// Publish the resolved config; undefined (no capture) drops it from the catalog.
		effect.proxy(rendition.config, this.out.catalog);

		// The pipeline outlives any one subscription: it is built as soon as capture runs and
		// #encode reads the live producer per frame rather than subscribing to it. Rebuilding on a
		// swap would close the AudioEncoder, which discards every chunk the codec still holds, and
		// would restart the framer mid-frame, so the output fell permanently behind its input.
		effect.run((effect) => {
			const enabled = effect.get(this.in.enabled);
			const capture = effect.get(this.in.capture);
			const format = capture ? effect.get(capture.out.format) : undefined;
			const fatal = effect.get(this.#fatal);
			if (!enabled || !format || fatal) return;

			this.#encode(broadcast.baseline, format, effect);
		});

		// Each subscription gets its own producer. Losing demand ends the epoch, as stopping the
		// pipeline does.
		effect.run((effect) => {
			const track = effect.get(rendition.track);
			if (!track) return;

			const live = {
				track,
				producer: new Container.Legacy.Producer(track, new Container.Legacy.Format("audio")),
			};
			this.#live = live;
			effect.cleanup(() => {
				this.#cut();
				if (this.#live === live) this.#live = undefined;
			});
		});

		effect.run((effect) => {
			const enabled = effect.get(this.in.enabled);
			const capture = effect.get(this.in.capture);
			const format = capture ? effect.get(capture.out.format) : undefined;
			const track = effect.get(rendition.track);
			const fatal = effect.get(this.#fatal);

			// A dead encoder can't serve anyone, so the current subscriber and every later one get
			// the real error rather than a track that stays silent.
			if (fatal) track?.close(fatal);

			effect.set(this.#out.active, enabled && !!format && !!track && !fatal, false);
		});

		// Claim the configured bitrate so a co-resident video encoder's share is
		// honest. Wait for a bitrate so we never claim 0. The grant is ignored:
		// following it for Opus is out of scope.
		effect.run((effect) => {
			const enabled = effect.get(this.in.enabled);
			const track = effect.get(rendition.track);
			const allocator = effect.get(this.in.bandwidth);
			if (!enabled || !track || !allocator) return;

			let reservation: Moq.Bandwidth.Reservation | undefined;
			effect.subscribe(this.#config, (config) => {
				const bitrate = config?.catalog.bitrate;
				if (bitrate === undefined) return;
				if (!reservation) reservation = allocator.reserve(track.demand(), bitrate);
				else reservation.update(bitrate);
			});
			effect.cleanup(() => reservation?.close());
		});
	}

	// Derive the encoder config from the captured format and the codec. Re-runs whenever either changes, so a
	// codec update (bitrate, frame duration) reconfigures without waiting for a channel-count change.
	//
	// Gated on `enabled` the same way the video encoder is: a disabled rendition has to drop out of
	// the catalog, and a sample source keeps its format while muted rather than tearing down.
	#runConfig(effect: Effect): void {
		const fade = effect.get(this.fade);
		if (!Number.isFinite(fade) || fade < 0)
			throw new Error(`audio fade must be a finite, non-negative number of ms: ${fade}`);
		this.#fade = fade;

		const capture = effect.get(this.in.capture);
		const captured = capture ? effect.get(capture.out.format) : undefined;
		if (!effect.get(this.in.enabled) || !captured) {
			effect.set(this.#config, undefined);
			return;
		}

		effect.set(this.#config, resolve(captured, effect.get(this.codec)));
	}

	// Publish the config immediately so a consumer can request the demand-gated track. Once encoding
	// starts, republish Opus with the exact decoder description reported for that encoder config.
	#runCatalog(effect: Effect): void {
		const config = effect.get(this.#config)?.catalog;
		if (!config) {
			effect.set(this.#out.catalog, undefined);
			return;
		}

		const decoder = effect.get(this.#decoderDescription);
		const catalog = decoder?.config === config ? { ...config, description: decoder.description } : config;
		effect.set(this.#out.catalog, {
			...catalog,
			...this.#estimator.estimate,
		});
	}

	// Collect the encode-only Opus knobs that are set, reading the codec through the effect so the
	// encoder reconfigures when it changes. Undefined values are omitted so the browser keeps its defaults.
	#opusOptions(effect: Effect): OpusEncoderConfigExt {
		const codec = normalizeCodec(effect.get(this.codec));
		const opus: OpusEncoderConfigExt = {};
		if (codec.mime !== "opus") return opus;

		if (codec.complexity !== undefined) opus.complexity = codec.complexity;
		if (codec.packetlossperc !== undefined) opus.packetlossperc = codec.packetlossperc;
		if (codec.useinbandfec !== undefined) opus.useinbandfec = codec.useinbandfec;

		return opus;
	}

	// End the epoch with a discontinuity marker (see Container.Legacy.Producer.discontinuity) where the
	// submitted media ends, so a subscriber that stays across the break, or joins during it, doesn't
	// read the audio before it as live. Called whenever demand disappears or the pipeline stops.
	#cut(): void {
		const end = this.#next;
		this.#next = undefined;
		const live = this.#live;
		if (end === undefined || !live || live.track.closed.peek() !== undefined) return;
		this.#floor = end;
		live.producer.discontinuity(end);
	}

	// Encode captured audio frames into whichever track producer is live. The broadcast owns the
	// track's lifetime, so this never closes it; a fatal encoder error is reported through #fatal.
	#encode(baseline: Baseline, format: Format, effect: Effect): void {
		effect.spawn(async () => {
			// We're using an async polyfill temporarily for Safari support.
			await Util.Libav.polyfill();

			effect.run((effect: Effect) => {
				const resolved = effect.get(this.#config);
				if (!resolved) return;
				const config = resolved.catalog;

				const capture = effect.get(this.in.capture);
				const source = capture ? effect.get(capture.in.source) : undefined;
				const kind: Kind = source ? sourceKind(source) : "auto";
				const encoderConfig = toEncoderConfig(resolved, kind, this.#opusOptions(effect));

				// WebCodecs rejects input whose rate doesn't match the encoder config outright, so
				// anything arriving at a rate the codec can't carry (a 44.1kHz file as Opus) has to
				// be converted first. A capture graph already runs at the right rate, so this is
				// usually nothing.
				const resampler =
					format.sampleRate === config.sampleRate
						? undefined
						: new Resampler({
								from: format.sampleRate,
								to: config.sampleRate,
								channels: config.numberOfChannels,
							});

				const framer = createFramer(resolved, config.sampleRate);

				const encoder = new AudioEncoder({
					output: (frame, metadata) => {
						if (frame.type !== "key") {
							throw new Error("only key frames are supported");
						}

						this.#setDecoderDescription(config, metadata?.decoderConfig?.description);

						this.#out.stats.update((stats) => ({
							frames: stats.frames + 1,
							bytes: stats.bytes + frame.byteLength,
						}));

						// Each audio frame is a keyframe, so its own group, which the relay can forward
						// without waiting for a group boundary. Loss is handled by the codec's PLC.
						const live = this.#live;
						if (!live) return;
						if (this.#floor !== undefined && frame.timestamp < this.#floor) return;
						live.producer.encode(frame, frame.timestamp as Time.Micro, true);
						if (this.#estimator.flush(frame.timestamp, baseline)) {
							const catalog = this.#out.catalog.peek();
							if (catalog) this.#out.catalog.set({ ...catalog, ...this.#estimator.estimate });
						}
					},
					error: (err) => {
						console.error("encoder error", err);
						// #runRegister owns the abort, so the current producer and every later one
						// are closed with this in one place.
						this.#fatal.set(err);
					},
				});
				// A fatal error already closed the codec, and closing it twice throws.
				effect.cleanup(() => {
					if (encoder.state !== "closed") encoder.close();
				});

				console.debug("encoding audio", encoderConfig);
				encoder.configure(encoderConfig);

				// Where the next frame starts if it continues the last one encoded.
				let contiguous: Time.Micro | undefined;

				const pipeline: Pipeline = {
					channelCount: config.numberOfChannels,
					push: (captured: AudioFrame) => {
						const input = resampler ? resampler.push(captured) : captured;
						if (!input) return;

						const frames = framer.push(input);
						for (const [i, data] of frames.entries()) {
							// The demand gate. The framer still consumes every sample so its timestamps stay
							// on the capture clock, but there is nowhere to send a chunk with no subscriber.
							if (!this.#live) continue;

							// Round to whole microseconds once, here, so a chunk's timestamp and the marker
							// placed at the next frame's start agree exactly.
							const timestamp = Math.round(data.timestamp) as Time.Micro;

							// Chrome stamps encoder output from the first input's timestamp plus the samples
							// encoded since, ignoring any later jump. Across a gap (demand, or a capture
							// discontinuity) the output would trail the capture clock by the gap, and the
							// next demand gap's marker would then sit ahead of everything encoded after it.
							// Restarting re-bases the output clock; the chunks it drops predate the gap.
							if (contiguous !== undefined && timestamp !== contiguous) {
								encoder.reset();
								encoder.configure(encoderConfig);
							}

							const joinedLength = data.channels.reduce((total, channel) => total + channel.length, 0);
							const joined = new Float32Array(joinedLength);

							data.channels.reduce((offset: number, channel: Float32Array): number => {
								joined.set(channel, offset);
								return offset + channel.length;
							}, 0);

							const frame = new AudioData({
								format: "f32-planar",
								sampleRate: config.sampleRate,
								numberOfFrames: data.channels[0].length,
								numberOfChannels: data.channels.length,
								timestamp,
								data: joined,
								transfer: [joined.buffer],
							});

							encoder.encode(frame);
							frame.close();
							// One input can complete several frames, and the framer has already advanced past all of them.
							contiguous = Math.round(frames[i + 1]?.timestamp ?? framer.next) as Time.Micro;
							this.#next = contiguous;
						}
					},
				};

				// Publish it last: the read loop starts pushing the moment this is visible.
				this.#pipeline = pipeline;
				effect.cleanup(() => {
					if (this.#pipeline !== pipeline) return;
					this.#pipeline = undefined;
					// Whatever stopped it (disable, a format or codec change, a fatal error), the
					// timeline breaks here.
					this.#cut();
				});
			});
		});
	}

	#setDecoderDescription(config: Catalog.AudioConfig, source: AllowSharedBufferSource | undefined): void {
		if (config.codec !== "opus" || !source) return;

		const bytes = ArrayBuffer.isView(source)
			? new Uint8Array(source.buffer, source.byteOffset, source.byteLength)
			: new Uint8Array(source);
		const description = Util.Hex.fromBytes(bytes);
		const current = this.#decoderDescription.peek();
		if (current?.config === config && current.description === description) return;

		this.#decoderDescription.set({ config, description });
	}

	close() {
		this.#signals.close();
	}
}

/**
 * The encode settings a {@link Codec} resolves to against a captured PCM format.
 *
 * The catalog is a decoder hint carrying whole milliseconds, so it can only round a frame duration.
 * {@link frameDuration} keeps the exact value the encoder is configured with, which is what lets
 * Opus run at 2.5 ms.
 */
type Resolved = {
	/** The rendition config published in the catalog. */
	catalog: Catalog.AudioConfig;

	/** The exact encoded frame duration, or undefined for a codec whose frame is a fixed sample count. */
	frameDuration?: Time.Micro;
};

/**
 * Resolve a {@link Codec} against the captured PCM format, giving what the encoder will run with
 * and the catalog rendition published alongside it.
 * @internal
 */
export function resolve(captured: Format, selected: Codec): Resolved {
	const codec = normalizeCodec(selected);

	// The catalog has to describe what the encoder emits, not what we feed it. A capture graph
	// already runs at a rate the codec supports, since Capture picks the AudioContext rate.
	// Decoded samples arrive at whatever rate the file was authored at, which Opus may not be
	// able to carry, so snap to one it can and let #encode resample into it.
	const rate = pickSampleRate(codec.mime, captured.sampleRate) ?? captured.sampleRate;

	const sampleRate = Catalog.u53(rate);
	const numberOfChannels = Catalog.u53(captured.channelCount);

	if (codec.mime === "aac") {
		return {
			catalog: {
				codec: AAC_CODEC,
				sampleRate,
				numberOfChannels,
				bitrate: Catalog.u53(codec.bitrate ?? captured.channelCount * AAC_BITRATE_PER_CHANNEL),
				container: { kind: "legacy" } as const,
				// Frames are raw (no ADTS header), so the decoder needs the AudioSpecificConfig to init.
				description: Util.Hex.fromBytes(Util.Aac.audioSpecificConfig(rate, captured.channelCount)),
			},
		};
	}

	const frameDuration = codec.frameDuration ?? OPUS_FRAME_DURATION;
	// Check here rather than letting AudioEncoder.configure throw: by then the rendition has been
	// advertised and requested, so the failure surfaces to a subscriber instead of the caller.
	if (!OPUS_FRAME_DURATIONS.includes(frameDuration)) {
		throw new Error(`opus frame duration must be ${OPUS_FRAME_DURATIONS.join("/")} ms: ${frameDuration}`);
	}

	return {
		catalog: {
			codec: "opus",
			sampleRate,
			numberOfChannels,
			bitrate: Catalog.u53(codec.bitrate ?? captured.channelCount * OPUS_BITRATE_PER_CHANNEL),
			container: { kind: "legacy" } as const,
		},
		frameDuration: Time.Micro.fromMilli(frameDuration),
	};
}

// Build the framer for a config, given the rate the PCM actually arrives at. That's the catalog rate
// for a capture graph, but a decoded file can arrive at a rate the codec doesn't carry (44100 for
// Opus), and the framer has to count the samples we're handed rather than the ones the encoder emits.
function createFramer(resolved: Resolved, sampleRate: number): Framer {
	const config = resolved.catalog;

	// WebCodecs copies input AudioData timestamps to encoded chunks. Align those inputs to codec frames
	// because the worklet's 128-sample quanta usually do not align with Opus frame boundaries.
	if (config.codec.startsWith("mp4a")) {
		return new Framer({
			sampleRate,
			channels: config.numberOfChannels,
			size: { samples: AAC_FRAME_SAMPLES },
		});
	}

	if (config.codec !== "opus") throw new Error(`unsupported audio codec: ${config.codec}`);
	return new Framer({
		sampleRate,
		channels: config.numberOfChannels,
		size: { duration: resolved.frameDuration ?? Time.Micro.fromMilli(OPUS_FRAME_DURATION) },
	});
}

// Resolve the bare codec shorthands to their full config object so callers can read fields uniformly.
function normalizeCodec(codec: Codec): OpusConfig | AacConfig {
	if (codec === "opus") return { mime: "opus" };
	if (codec === "aac") return { mime: "aac" };
	return codec;
}

// `application` and `signal` are in the WebCodecs spec but missing from lib.dom.d.ts.
// https://www.w3.org/TR/webcodecs-opus-codec-registration/#dom-opusencoderconfig
interface OpusEncoderConfigExt extends OpusEncoderConfig {
	application?: "voip" | "audio" | "lowdelay";
	signal?: "auto" | "voice" | "music";
}

// Opus settings implied by the audio kind. These are only defaults: any field set explicitly via
// OpusConfig (carried in opusOptions) overrides them, so a caller can always opt out. "auto" leaves
// every knob to the browser.
function opusKindDefaults(kind: Kind): OpusEncoderConfigExt {
	switch (kind) {
		case "voice":
			return { application: "voip", signal: "voice" };
		case "music":
			return { application: "audio", signal: "music" };
		default:
			return {};
	}
}

/**
 * Build the WebCodecs encoder config from the catalog (decoder) config, a Kind hint, and any
 * Opus-only knobs. Those knobs are kept out of the catalog since they only affect encoding. AAC has
 * no such knobs, so it just uses the shared base fields (codec/sampleRate/channels/bitrate).
 * @internal
 */
export function toEncoderConfig(resolved: Resolved, kind: Kind, opusOptions: OpusEncoderConfigExt): AudioEncoderConfig {
	const config = resolved.catalog;
	const encoderConfig: AudioEncoderConfig = {
		codec: config.codec,
		sampleRate: config.sampleRate,
		numberOfChannels: config.numberOfChannels,
		bitrate: config.bitrate,
	};

	if (config.codec.startsWith("mp4a")) {
		// Pin raw AAC: the catalog carries a synthesized AudioSpecificConfig, which is only valid for
		// raw frames. An ADTS default would make the frames self-describing and that description wrong.
		encoderConfig.aac = { format: "aac" };
	}

	if (config.codec === "opus") {
		// Start from the kind's defaults, then let explicit opusOptions win (undefined knobs were
		// already dropped upstream, so the spread only overrides what the caller actually set).
		const opus: OpusEncoderConfigExt = { ...opusKindDefaults(kind), ...opusOptions };

		// The exact duration, not the catalog's rounded jitter hint: WebCodecs rejects anything but
		// 2.5/5/10/20/40/60 ms, so 2.5 has to arrive as 2500 µs rather than 3000.
		if (resolved.frameDuration !== undefined) {
			opus.frameDuration = resolved.frameDuration;
		}

		if (Object.keys(opus).length > 0) {
			encoderConfig.opus = opus;
		}
	}

	return encoderConfig;
}

/**
 * Snap a rate to one the codec can actually encode at.
 *
 * The capture runs at whatever suits the device, and several renditions may share it, so each
 * rendition converts on its own. WebCodecs rejects input whose rate doesn't match the configured
 * one rather than converting for us, which is what #encode's resampler is for.
 */
function pickSampleRate(mime: CodecMime, requested: number | undefined): number | undefined {
	// Treat a nonsense rate as unknown, rather than snapping it to the codec's floor (7350Hz for AAC).
	const rate = requested !== undefined && Number.isFinite(requested) && requested > 0 ? requested : undefined;

	// Opus only decodes at a handful of rates, and 44.1kHz is not one of them.
	if (mime === "opus") return Util.Opus.pickRate(rate ?? Util.Opus.DEFAULT_SAMPLE_RATE);

	// The AAC table includes 44100, so an unknown rate can fall through to whatever we captured.
	return rate !== undefined ? Util.Aac.pickRate(rate) : undefined;
}
